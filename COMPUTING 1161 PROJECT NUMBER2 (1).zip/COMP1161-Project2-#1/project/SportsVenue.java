package project;

import java.util.Scanner;

/**
 * SportsVenue
 */
public class SportsVenue extends Venue {
	private double competitorArea;
	private double spectatorArea;
	private int numSecurity;

	/**
	 * SportsVenue constructor
	 * 
	 * @param name           is the name of the sports venue.
	 * @param competitorArea is the size of the competitor area for the sports
	 *                       venue.
	 * @param spectatorArea  is the size of the spectator area for the sports venue.
	 * @param numSecurity    is the number of security personnel for the sports
	 *                       venue.
	 * @param basePrice      is the base price of the sports venue.
	 * @param lev            is the alert level of the sports venue.
	 */
	public SportsVenue(String name, double competitorArea, double spectatorArea, int numSecurity, double basePrice,
			int lev) {
		super(name, competitorArea + spectatorArea, basePrice, lev);
		this.competitorArea = competitorArea;
		this.spectatorArea = spectatorArea;
		this.numSecurity = numSecurity;

	}

	public double getSize() {
		return competitorArea + spectatorArea;
	}

	public int countSecurity() {
		return numSecurity;
	}

	public double getCompArea() {
		return competitorArea;
	}

	public double getSpecArea() {
		return spectatorArea;

	}

	public int getNumSecurity() {
		return numSecurity;
	}

	public void setCompArea(double competitorArea) {

		this.competitorArea = competitorArea;
	}

	public void setSpecArea(double spectatorArea) {

		this.spectatorArea = spectatorArea;
	}

	public void setNumSecurity(int numSecurity) {

		this.numSecurity = numSecurity;
	}

	public double getEstimate(String type) {
		double price = basePrice;
		if (type.equals("PARTY"))
			price += partyPrep;
		if (type.equals("TRAINING"))
			price += trainPrep;

		// System.out.println(this.getName()+":estimate to hold a "+type +" is "+
		// price);
		return price;

	}

	public String toString() {
		return "ID:" + this.getId() + ";" + this.getName() + ";#Events:" + this.getApprovedEvents().size()
				+ ";Compet Area:" + competitorArea + ";Spec Area:" + spectatorArea + ";#Sec:" + numSecurity;

	}

	public String toFile() {
		return "" + this.getId() + ";" + this.getName() + ";" + this.getApprovedEvents().size() + ";" + competitorArea
				+ ";" + spectatorArea + ";" + numSecurity;

	}

	/**
	 * Updates the instance values of the SportsVenue.
	 * 
	 * @param scan used to retrieve user input.
	 */
	@Override
	public void updateLocalData(Scanner scan) {
		try {
			scan.nextLine();
			String messageFormat = "Hit enter to keep %s as [%s], or enter new %s";
			System.out.println(String.format(messageFormat, "name", getName(), "name"));
			String name = scan.nextLine();
			if (!name.equals("")) {
				setName(name);
			}
			System.out.println(String.format(messageFormat, "competitor area size", Double.toString(getCompArea()),
					"competitor area size"));
			String competitorArea = scan.nextLine();
			if (!competitorArea.equals("")) {
				setCompArea(Double.parseDouble(competitorArea));
			}
			System.out.println(String.format(messageFormat, "spectator area size", Double.toString(getSpecArea()),
					"spectator area size"));
			String spectatorArea = scan.nextLine();
			if (!spectatorArea.equals("")) {
				setSpecArea(Double.parseDouble(spectatorArea));
			}
			System.out.println(String.format(messageFormat, "number security guards",
					Integer.toString(getNumSecurity()), "number security guards"));
			String numSecurity = scan.nextLine();
			if (!numSecurity.equals("")) {
				setNumSecurity(Integer.parseInt(numSecurity));
			}
			System.out.println(String.format(messageFormat, "price", Double.toString(getPrice()), "price"));
			String price = scan.nextLine();
			if (!price.equals("")) {
				setPrice(Double.parseDouble(price));
			}
			System.out
					.println(String.format(messageFormat, "alert level", Integer.toString(getLevel()), "alert level"));
			String level = scan.nextLine();
			if (!level.equals("")) {
				setLevel(Integer.parseInt(level));
			}
		} catch (NumberFormatException exception) {
		} catch (Exception exception) {
		}
	}
}
