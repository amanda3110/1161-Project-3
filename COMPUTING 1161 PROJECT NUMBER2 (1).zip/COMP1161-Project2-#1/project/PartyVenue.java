package project;

import java.util.Scanner;

/**
 * PartyVenue
 */
public class PartyVenue extends Venue {
	double stageArea;
	double barArea, foodArea;
	int numSecurity;

	/**
	 * PartyVenue Constructor
	 * 
	 * @param name        is the name of the party venue.
	 * @param stageArea   is the size of the stage area for the party venue.
	 * @param barArea     is the size of the bar area for the party venue.
	 * @param foodArea    is the size of the food area for the party venue.
	 * @param numSecurity is the number of security personnel for the party venue.
	 * @param basePrice   is the base price of the party venue.
	 * @param lev         is the alert level of the party venue.
	 */
	public PartyVenue(String name, double stageArea, double barArea, double foodArea, int numSecurity, double basePrice,
			int lev) {
		super(name, stageArea + barArea + foodArea, basePrice, lev);
		this.numSecurity = numSecurity;
		this.stageArea = stageArea;
		this.barArea = barArea;
		this.foodArea = foodArea;

	}

	public double getEstimate(String type) {
		double price = basePrice;
		if (type.equals("PARTY"))
			price += partyPrep;
		if (type.equals("SPORT"))
			price += sportsPrep;
		if (type.equals("TRAINING"))
			price += trainPrep;

		// System.out.println(this.getName()+":estimate to hold a "+type +" is "+
		// price);
		return price;

	}

	public double getCurrStage() {
		return stageArea;
	}

	public double getBarArea() {
		return barArea;
	}

	public double getFoodArea() {
		return foodArea;
	}

	public int getNumSecurity() {
		return numSecurity;
	}

	public void setStageArea(double stageArea) {

		this.stageArea = stageArea;
	}

	public void setFoodArea(double foodArea) {

		this.foodArea = foodArea;
	}

	public void setBarArea(double barArea) {

		this.barArea = barArea;
	}

	public void setNumSecurity(int numSecurity) {

		this.numSecurity = numSecurity;
	}

	public String toString() {
		return "ID:" + this.getId() + ";" + this.getName() + ";#Events:" + this.getApprovedEvents().size()
				+ ";Stage Area:" + stageArea + ";Bar Area:" + barArea + ";Food Area:" + foodArea + ";#Sec"
				+ numSecurity;

	}

	public String toFile() {
		return "" + this.getId() + ";" + this.getName() + ";" + this.getApprovedEvents().size() + ";" + stageArea + ";"
				+ barArea + ";" + foodArea + ";" + numSecurity;

	}

	/**
	 * Updates the instance values of the PartyVenue.
	 * 
	 * @param scan used to retrieve user input.
	 */
	@Override
	public void updateLocalData(Scanner scan) {
		try {
			scan.nextLine();
			String messageFormat = "Hit enter to keep %s as [%s], or enter new %s";
			System.out.println(String.format(messageFormat, "name", getName(), "name"));
			String name = scan.nextLine();
			if (!name.equals("")) {
				setName(name);
			}
			System.out.println(String.format(messageFormat, "stage area size", Double.toString(getCurrStage()),
					"stage area size"));
			String stageArea = scan.nextLine();
			if (!stageArea.equals("")) {
				setStageArea(Double.parseDouble(stageArea));
			}
			System.out.println(
					String.format(messageFormat, "bar area size", Double.toString(getBarArea()), "bar area size"));
			String barArea = scan.nextLine();
			if (!barArea.equals("")) {
				setBarArea(Double.parseDouble(barArea));
			}
			System.out.println(
					String.format(messageFormat, "food area size", Double.toString(getFoodArea()), "food area size"));
			String foodArea = scan.nextLine();
			if (!foodArea.equals("")) {
				setFoodArea(Double.parseDouble(foodArea));
			}
			System.out.println(String.format(messageFormat, "number security guards",
					Integer.toString(getNumSecurity()), "number security guards"));
			String numSecurity = scan.nextLine();
			if (!numSecurity.equals("")) {
				setNumSecurity(Integer.parseInt(numSecurity));
			}
			System.out.println(String.format(messageFormat, "price", Double.toString(getPrice()), "price"));
			String price = scan.nextLine();
			if (!price.equals("")) {
				setPrice(Double.parseDouble(price));
			}
			System.out
					.println(String.format(messageFormat, "alert level", Integer.toString(getLevel()), "alert level"));
			String level = scan.nextLine();
			if (!level.equals("")) {
				setLevel(Integer.parseInt(level));
			}
		} catch (NumberFormatException exception) {
		} catch (Exception exception) {
		}
	}
}
