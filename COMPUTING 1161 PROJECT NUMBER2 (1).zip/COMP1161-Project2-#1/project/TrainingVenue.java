package project;

import java.util.Scanner;

/**
 * TrainingVenue
 */
public class TrainingVenue extends Venue {
	private double instructorArea;
	private double otherArea;

	/**
	 * TrainingVenue constructor
	 * 
	 * @param name           is the name of the training venue.
	 * @param instructorArea is the size of the instructor area for the training
	 *                       venue.
	 * @param otherArea      is the size of the other area for the training venue.
	 * @param basePrice      is the base price of the training venue.
	 * @param lev            is the alert level of the training venue.
	 */
	public TrainingVenue(String name, double instructorArea, double otherArea, double basePrice, int lev) {
		super(name, instructorArea + otherArea, basePrice, lev);
		this.instructorArea = instructorArea;
		this.otherArea = otherArea;

	}

	public double getEstimate(String type) {
		double price = basePrice;
		if (type.equals("PARTY"))
			price += partyPrep;
		if (type.equals("SPORT"))
			price += sportsPrep;

		// System.out.println(this.getName()+":estimate to hold a "+type +" is "+
		// price);
		return price;

	}

	public double getInstructorArea() {
		return instructorArea;
	}

	public double getOtherArea() {
		return otherArea;

	}

	public void setInstructorArea(double instructorArea) {

		this.instructorArea = instructorArea;
	}

	public void setOtherArea(double otherArea) {

		this.otherArea = otherArea;
	}

	public String toString() {
		return "ID:" + this.getId() + ";" + this.getName() + ";#Events:" + this.getApprovedEvents().size()
				+ ";Inst.Area" + instructorArea + ";Oth.Area" + otherArea;

	}

	public String toFile() {
		return "" + this.getId() + ";" + this.getName() + ";" + this.getApprovedEvents().size() + ";" + instructorArea
				+ ";" + otherArea;
	}

	/**
	 * Updates the instance values of the TrainingVenue.
	 * 
	 * @param scan used to retrieve user input.
	 */
	@Override
	public void updateLocalData(Scanner scan) {
		try {
			scan.nextLine();
			String messageFormat = "Hit enter to keep %s as [%s], or enter new %s";
			System.out.println(String.format(messageFormat, "name", getName(), "name"));
			String name = scan.nextLine();
			if (!name.equals("")) {
				setName(name);
			}
			System.out.println(String.format(messageFormat, "instructor area size",
					Double.toString(getInstructorArea()), "instructor area size"));
			String instructorArea = scan.nextLine();
			if (!instructorArea.equals("")) {
				setInstructorArea(Double.parseDouble(instructorArea));
			}
			System.out.println(String.format(messageFormat, "other area size", Double.toString(getOtherArea()),
					"other area size"));
			String otherArea = scan.nextLine();
			if (!otherArea.equals("")) {
				setOtherArea(Double.parseDouble(otherArea));
			}
			System.out.println(String.format(messageFormat, "price", Double.toString(getPrice()), "price"));
			String price = scan.nextLine();
			if (!price.equals("")) {
				setPrice(Double.parseDouble(price));
			}
			System.out
					.println(String.format(messageFormat, "alert level", Integer.toString(getLevel()), "alert level"));
			String level = scan.nextLine();
			if (!level.equals("")) {
				setLevel(Integer.parseInt(level));
			}
		} catch (NumberFormatException exception) {
		} catch (Exception exception) {
		}
	}

}
