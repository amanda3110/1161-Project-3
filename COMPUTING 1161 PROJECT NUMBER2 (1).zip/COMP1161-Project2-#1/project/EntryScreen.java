package project;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class EntryScreen {

	public EntryScreen() {
	}

	public ArrayList<Promoter> managePromoters(Scanner scan, ArrayList<Promoter> proms, Ministry min,
			ArrayList<Venue> vens) throws NumberFormatException {
		ReportScreen r = new ReportScreen();
		char mchoice = 'c';
		String menu = "";
		while (mchoice != 'X') {
			String menuOptions = "[A]dd/Create promoter\n[E]dit/Update promoter\n";
			menuOptions += "[L]ist/Read promoters\n[D]elete promoter\nE[x]it\n";
			System.out.println(menuOptions);
			menu = scan.next().toUpperCase();
			mchoice = menu.charAt(0);
			switch (mchoice) {
			case 'A': {
				Promoter p = createPromoter(scan, min, vens);
				if (p != null)
					proms.add(p);
				break;
			}
			case 'L': {
				Collections.sort(proms);
				r.listPromoters(proms, System.out);
				break;
			}
			case 'E': {
				System.out.println("Please enter the ID of the promoter to be updated:");
				int pid = Integer.parseInt(scan.next());
				int pdx = findPromoter(proms, pid);
				if (pdx >= 0)
					proms.get(pdx).updateLocalData(scan);
				else
					System.out.println("Promoter with id " + pid + " not found.");
				break;
			}
			case 'D': {
				System.out.println("Please enter the ID of the promoter to be deleted:");
				int pid = Integer.parseInt(scan.next());
				int pdx = findPromoter(proms, pid);

				if (pdx >= 0)
					proms.remove(pdx);
				else
					System.out.println("Promoter with id " + pid + " not found.");
				break;
			}

			}

		}
		return proms;
	}

	public Promoter createPromoter(Scanner scan, Ministry min, ArrayList<Venue> vens) {
		Promoter p = null;
		try {
			System.out.println("Please enter Promoter Name:");
			String name = scan.next();
			System.out.println("Please enter Promoter Budget:");
			double budget = Double.parseDouble(scan.next());
			p = new Promoter(name, budget, min, vens);
		} catch (NumberFormatException nfe) {
		}
		return p;
	}

	public int findPromoter(ArrayList<Promoter> proms, int pid) {
		int pdx = -1;
		int currdx = 0;
		while ((currdx < proms.size()) && (pdx == -1)) {
			if (proms.get(currdx).getId() == pid)
				pdx = currdx;
			currdx++;

		}

		return pdx;

	}

	public ArrayList<Venue> manageVenues(Scanner scan, ArrayList<Venue> vens) {
		ReportScreen r = new ReportScreen();
		// code required here to implement a venue management screen
		char choice = 'z';
		while (choice != 'X') {
			System.out.println("[A]dd/Create venue\n[E]dit/Update venue\n[L]ist/Read Venues\n[D]elete venue\nE[x]it\n");
			choice = scan.next().toUpperCase().charAt(0);
			switch (choice) {
			case 'A':
				Venue venue = createVenue(scan);
				if (venue != null) {
					vens.add(venue);
				}
				break;
			case 'E':
				System.out.println("Please enter the ID of the venue to be updated:");
				int updatedVenueId = Integer.parseInt(scan.next());
				int venueId = findVenue(vens, updatedVenueId);
				if (venueId > -1) {
					vens.get(venueId).updateLocalData(scan);
				} else {
					System.out.println("Venue with id " + updatedVenueId + " not found.");
				}
				break;
			case 'L':
				Collections.sort(vens);
				r.listVenues(vens, System.out);
				break;
			case 'D':
				System.out.println("Please enter the ID of the venue to be deleted:");
				int deletedVenueId = Integer.parseInt(scan.next());
				int venueLookupId = findVenue(vens, deletedVenueId);
				if (venueLookupId > -1) {
					vens.remove(venueLookupId);
				} else {
					System.out.println("Venue with id " + deletedVenueId + " not found.");
				}
				break;
			}
		}
		return vens;
	}

	public Venue createVenue(Scanner scan) {
		Venue v = null;
		char mchoice = 'c';
		String menu = "";

		// code needed to obtain the information required to represent a venue and
		// create an appropriate venue object
		try {
			menu = "General Purpose [V]enue\n[P]arty venue\n[S]ports venue\n[T]raining Venue\nE[x]it to previous menu\n";
			System.out.println(menu);
			mchoice = scan.next().toUpperCase().charAt(0);
			switch (mchoice) {
			case 'V':
				System.out.println("Please enter Venue Name:");
				String venueName = scan.next();
				System.out.println("Please enter Venue Size:");
				double size = Double.parseDouble(scan.next());
				System.out.println("Please enter Venue Base Price:");
				double venueBasePrice = Double.parseDouble(scan.next());
				System.out.println("Please enter Venue Alert Level:");
				int venueLevel = Integer.parseInt(scan.next());
				v = new Venue(venueName, size, venueBasePrice, venueLevel);
				break;
			case 'P':
				System.out.println("Please enter Party Venue Name:");
				String partyVenueName = scan.next();
				System.out.println("Please enter Party Stage Area Size:");
				double stageArea = Double.parseDouble(scan.next());
				System.out.println("Please enter Party Bar Area Size:");
				double barArea = Double.parseDouble(scan.next());
				System.out.println("Please enter Party Food Area Size:");
				double foodArea = Double.parseDouble(scan.next());
				System.out.println("Please enter Party Security Number:");
				int partyNumSecurity = Integer.parseInt(scan.next());
				System.out.println("Please enter Party Venue Base Price:");
				double partyBasePrice = Double.parseDouble(scan.next());
				System.out.println("Please enter Party Venue Alert Level:");
				int partyLevel = Integer.parseInt(scan.next());
				v = new PartyVenue(partyVenueName, stageArea, barArea, foodArea, partyNumSecurity, partyBasePrice,
						partyLevel);
				break;
			case 'S':
				System.out.println("Please enter Sports Venue Name:");
				String sportsVenueName = scan.next();
				System.out.println("Please enter Sports Competitor Area Size:");
				double competitorArea = Double.parseDouble(scan.next());
				System.out.println("Please enter Sports Spectator Area Size:");
				double spectatorArea = Double.parseDouble(scan.next());
				System.out.println("Please enter Sports Security Number:");
				int sportsNumSecurity = Integer.parseInt(scan.next());
				System.out.println("Please enter Sports Venue Base Price:");
				double sportsBasePrice = Integer.parseInt(scan.next());
				System.out.println("Please enter Sports Venue Alert Level:");
				int sportsLevel = Integer.parseInt(scan.next());
				v = new SportsVenue(sportsVenueName, competitorArea, spectatorArea, sportsNumSecurity, sportsBasePrice,
						sportsLevel);
				break;
			case 'T':
				System.out.print("Please enter Training Venue Name:");
				String trainingVenueName = scan.next();
				System.out.println("Please enter Training Instructor Area Size:");
				double instructorArea = Double.parseDouble(scan.next());
				System.out.print("Please enter Training Other Area Size:");
				double otherArea = Double.parseDouble(scan.next());
				System.out.print("Please enter Training Venue Base Price:");
				double trainingBasePrice = Double.parseDouble(scan.next());
				System.out.println("Please enter Training Venue Alert Level:");
				int trainingLevel = Integer.parseInt(scan.next());
				v = new TrainingVenue(trainingVenueName, instructorArea, otherArea, trainingBasePrice, trainingLevel);
				break;
			}
		} catch (NumberFormatException exception) {
		}
		return v;
	}

	public int findVenue(ArrayList<Venue> vens, int vid) {
		int vdx = -1;
		//// code needed here to find venue with id VID in arraylist of venues
		for (int index = 0; index < vens.size(); index++) {
			if (vens.get(index).getId() == vid) {
				vdx = index;
				break;
			}
		}
		return vdx;
	}
}
